package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class hooks {
	
	
	/*
	 * FLOW OF HOOKS CLASS
	 * Before --> Background --> Scenario --> After
	 * */
	
	
	@Before("@Netbanking")
	public void netBankingSetup() {
		System.out.println("**********************************");
		System.out.println("steup the entries in the Netbanking databse");
	}
	
	@After
	public void tearDown() {
		System.out.println("clear the entries");
	}
	
	@Before("@Mortgage")
	public void mortgageSetup() {
		System.out.println("steup the entries in the mortgage databse");
	}
}
