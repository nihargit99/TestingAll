package stepDefinitions;

import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;




public class MainSteps {
	@Given("User is on Netbanking landing page")
	public void user_is_on_netbanking_landing_page() {
	    System.out.println("User landed on Netbanking page");

	
	}
	// This method is for normal method
//	@When("User login into application with {string} and password as {string}")
//	public void user_login_into_application_with_and_password_as(String username, String password) {
//		System.out.println("User name is: "+username +" and the pasasword is: "+password);
//	  
//	}
	
	// This method is for regex method
	@When("^User login into application with (.+) and password as (.+)$")
	public void user_login_into_application_with_and_password_as(String username, String password) {
		System.out.println("User name is: "+username +" and the pasasword is: "+password);
	  
	}
	
	
	@Given("User is on Practice landing page")
	public void user_is_on_practice_landing_page() {
		System.out.println("USer landed on Practice page");
	   
	}
	
	
	@When("User is Signup into application")
	public void user_is_signup_into_application(List<String> data) {
		System.out.println(data.get(0));
		System.out.println(data.get(1));
		System.out.println(data.get(2));
		System.out.println(data.get(3));
	}
	
	
	@Then("Homepage is displayed")
	public void homepage_is_displayed() {
		System.out.println("User seeing Homepage");
		
	}
	
	
	@Then("Cards are displayed")
	public void cards_are_displayed() {
		System.out.println("User seeing the cards");
		
	}
	@Given ("steup the entries in the databse")
	public void setupEntries() {
		System.out.println("**********************************");
		System.out.println("steup the entries in the databse");
	}
	
	@When ("lunch the browser from config variables")
	public void lunchBrowser() {
		System.out.println("lunch the browser from config variables");
		
	}
	
	@When ("hit the home page url of banking site")
	public void hitUrl() {
		System.out.println("Hit the url");
	}
	

}
