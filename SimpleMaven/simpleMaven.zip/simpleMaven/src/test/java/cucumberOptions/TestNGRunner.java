package cucumberOptions;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


/*
 * The Runner file is used to run any test-case
 * features: just give the location of folder that contains features
 * glue: give the step definition folder name
 * monochrome=true: this helps to provide output in plain English
 * tags: If we need to execute any specific test. Then this time we can use this tag, the tag is needed to give in the respective feature
 * plugin: what kind of reports we need
 * dryRun= true: it helps to make sure all step definitions associated with feature file.
 * 
 * */


@CucumberOptions(features="src/test/java/features",dryRun=true,
glue="stepDefinitions",monochrome=true,tags="@SmokeTest or @RegressionTest",
plugin= {"pretty","html:target/report.html"})

public class TestNGRunner extends AbstractTestNGCucumberTests{
	
	

}
