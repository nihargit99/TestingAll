package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.LegalLocators;
import utils.base;
import utils.helper;
import utils.report;

public class Legalpage {
	
	helper helpers;
	WebDriver driver;
	
	public Legalpage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);
	}
	
	public void clickTermsOfUse(String TermsOfUse) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.termsOfUse, 10);
			helpers.waitForElementToBeClickable(LegalLocators.termsOfUse, 10);
			helpers.clickOnElement(LegalLocators.termsOfUse);
			Thread.sleep(2000);
			String termsOfUse = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Terms Of Use: " + termsOfUse);
			System.out.println("=====================================================================");
			helpers.softAsserting(termsOfUse, TermsOfUse);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Terms Of Use and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Terms Of Use ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Terms Of Use and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Terms Of Use and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Terms Of Use and verify URL");
		}
	}
	
	public void clickTermsAndConditions(String TermsAndConditions) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.termsAndConditions, 10);
			helpers.waitForElementToBeClickable(LegalLocators.termsAndConditions, 10);
			helpers.clickOnElement(LegalLocators.termsAndConditions);
			Thread.sleep(2000);
			String termsAndConditions = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Terms And Conditions: " + termsAndConditions);
			System.out.println("=====================================================================");
			helpers.softAsserting(termsAndConditions, TermsAndConditions);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Terms And Conditions and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Terms And Conditions");
			hooks.test.log(Status.FAIL, "Not able Clicked on Terms And Conditions and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Terms And Conditions and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Terms And Conditions and verify URL");
		}
	}
	
	public void clickPrivacyPolicy(String PrivacyPolicy) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.privacyPolicy, 10);
			helpers.waitForElementToBeClickable(LegalLocators.privacyPolicy, 10);
			helpers.clickOnElement(LegalLocators.privacyPolicy);
			Thread.sleep(2000);
			String privacyPolicy = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Privacy Policy: " + privacyPolicy);
			System.out.println("=====================================================================");
			helpers.softAsserting(privacyPolicy, PrivacyPolicy);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Privacy Policy and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Privacy Policy");
			hooks.test.log(Status.FAIL, "Not able Clicked on Privacy Policy and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Privacy Policy and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Privacy Policy and verify URL");
		}
	}

	public void clickCaliforniaProp65(String CaliforniaProp65) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.CALIFORNIAPROP65, 10);
			helpers.waitForElementToBeClickable(LegalLocators.CALIFORNIAPROP65, 10);
			helpers.clickOnElement(LegalLocators.CALIFORNIAPROP65);
			Thread.sleep(2000);
			String californiaProp65 = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking California Prop 65: " + californiaProp65);
			System.out.println("=====================================================================");
			helpers.softAsserting(californiaProp65, CaliforniaProp65);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Privacy Policy and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of California Prop 65");
			hooks.test.log(Status.FAIL, "Not able Clicked on California Prop 65 and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on California Prop 65 and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on California Prop 65 and verify URL");
		}
	}
	
	public void clickImprint(String Imprint) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.imprint, 10);
			helpers.waitForElementToBeClickable(LegalLocators.imprint, 10);
			helpers.clickOnElement(LegalLocators.imprint);
			Thread.sleep(2000);
			String imprint = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking imprint: " + imprint);
			System.out.println("=====================================================================");
			helpers.softAsserting(imprint, Imprint);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on imprint and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of imprint");
			hooks.test.log(Status.FAIL, "Not able Clicked on imprint and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on imprint and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on imprint and verify URL");
		}
	}
	
	public void clickAccessibilityStatement(String AccessibilityStatement) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.accessibility, 10);
			helpers.waitForElementToBeClickable(LegalLocators.accessibility, 10);
			helpers.clickOnElement(LegalLocators.accessibility);
			Thread.sleep(2000);
			String accessibilityStatement = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Accessibility Statement: " + accessibilityStatement);
			System.out.println("=====================================================================");
			helpers.softAsserting(accessibilityStatement, AccessibilityStatement);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Accessibility Statement and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Accessibility Statement");
			hooks.test.log(Status.FAIL, "Not able Clicked on Accessibility Statement and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Accessibility Statement and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Accessibility Statement and verify URL");
		}
	}
	
	public void clickCaliforniaSupplyChain(String CaliforniaSupplyChainAct) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.californiaSupply, 10);
			helpers.waitForElementToBeClickable(LegalLocators.californiaSupply, 10);
			helpers.clickOnElement(LegalLocators.californiaSupply);
			Thread.sleep(2000);
			String californiaSupplyChainAct = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking California Supply Chain: " + californiaSupplyChainAct);
			System.out.println("=====================================================================");
			helpers.softAsserting(californiaSupplyChainAct, CaliforniaSupplyChainAct);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on California Supply Chain and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of California Supply Chain");
			hooks.test.log(Status.FAIL, "Not able Clicked on California Supply Chain and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on California Supply Chain and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on California Supply Chain and verify URL");
		}
	}
	
	public void clickCaliforniaPrivacyRights(String CaliforniaPrivacyRights) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.californiaPrivacy, 10);
			helpers.waitForElementToBeClickable(LegalLocators.californiaPrivacy, 10);
			helpers.clickOnElement(LegalLocators.californiaPrivacy);
			Thread.sleep(2000);
			String californiaPrivacyRights = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking California Privacy Rights: " + californiaPrivacyRights);
			System.out.println("=====================================================================");
			helpers.softAsserting(californiaPrivacyRights, CaliforniaPrivacyRights);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on California Privacy Rights and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of California Privacy Rights");
			hooks.test.log(Status.FAIL, "Not able Clicked on California Privacy Rights and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on California Privacy Rights and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on California Privacy Rights and verify URL");
		}
	}
	
	public void verifyLegal(String Legal) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(LegalLocators.leaglText, 10);
			helpers.waitForElementToBeClickable(LegalLocators.leaglText, 10);
			String legal = helpers.getText(LegalLocators.leaglText);
			System.out.println("================================================================");
			System.out.println(legal);
			System.out.println("================================================================");
			helpers.softAsserting(Legal, legal);
			hooks.test.log(Status.PASS, "verify legal Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the legal text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the legal text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the legal text");
		}
	}

}
