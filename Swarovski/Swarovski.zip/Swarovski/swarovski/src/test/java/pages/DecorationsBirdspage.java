package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.CrystalPendatantsLocators;
import uistore.DecorationBirdsLocators;

import uistore.WatchImberLocators;
import utils.base;
import utils.helper;
import utils.report;

public class DecorationsBirdspage {
	WebDriver driver;
	helper helpers;

	public DecorationsBirdspage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);
	}

	public void hoverOnDecorations() {
		try {
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.decorations, 10);
			helpers.waitForElementToBeClickable(DecorationBirdsLocators.decorations, 10);
			helpers.hoverOverElement(DecorationBirdsLocators.decorations);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Hover Successful on Decorations");
		} catch (Exception e) {
			System.out.println("This is catch block error of hoverOnDecorations ");
			hooks.test.log(Status.FAIL, "Hover Failure");
			String screenshotPath = report.captureScreenShot("Hover Failure");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Hover Failure");
		}
	}

	public void clickOnBirds() {
		try {
			helpers.scrollByPixel(0, 300);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.birds, 10);
			helpers.waitForElementToBeClickable(DecorationBirdsLocators.birds, 10);
			helpers.clickOnElement(DecorationBirdsLocators.birds);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Clicked on Birds");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnBirds ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Sunglasses");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Birds");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Birds");
		}
	}

	public void verifyTheUrlForBirds(String birds) {
		try {
			Thread.sleep(1000);
			String Birds = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Sunglass: " + Birds);
			System.out.println("=====================================================================");
			helpers.softAssertContaing(Birds, birds);
			hooks.test.log(Status.PASS, "verify Url after Click on Birds");

		} catch (Exception e) {
			System.out.println("This is catch block error of verifyTheUrlForBirds ");
			hooks.test.log(Status.FAIL, "Not able to verify Url after Click on Birds");
			String screenshotPath = report.captureScreenShot("Not able to verify Url after Click on Birds");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to verify Url after Click on Birds");
		}
	}

	public void clickOnMetal() {
		try {
//			helpers.scrollByPixel(0, 430);
			Thread.sleep(1000);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.metal, 10);
			helpers.waitForElementToBeClickable(DecorationBirdsLocators.metal, 10);
			helpers.clickOnElement(DecorationBirdsLocators.metal);
			hooks.test.log(Status.PASS, "click On Metal");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnMetal ");
			hooks.test.log(Status.FAIL, "Not able to click On Metal");
			String screenshotPath = report.captureScreenShot("Not able to click On Metal");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Metal");
		}
	}

	public void ShowProductsForBirds() {
		try {
			helpers.scrollByPixel(0, 420);
			Thread.sleep(2000);

			/*
			 * Here calling the show product from another test case as both the Xpaths are same
			 */
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.showProduct, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.showProduct, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.showProduct);
			hooks.test.log(Status.PASS, "click On Show Products");
		} catch (Exception e) {
			System.out.println("This is catch block error of ShowProductsForSunglasses ");
			hooks.test.log(Status.FAIL, "Not able to click On Show Products");
			String screenshotPath = report.captureScreenShot("Not able to click On Show Products");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Show Products");
		}
	}

	public void verifyBirdsText(String DBirds) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.verifyBirds, 10);
			String dbirds = helpers.getText(DecorationBirdsLocators.verifyBirds);
			System.out.println("================================================================");
			System.out.println(dbirds);
			System.out.println("================================================================");
			helpers.softAssertContaing(DBirds, dbirds);
			hooks.test.log(Status.PASS, "verify Birds Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Birds text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Birds text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Birds text");
		}
	}

	public void clickOnFirstProductForBirds() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 450);
			helpers.waitForElementToBeVisible(WatchImberLocators.firstProduct, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.firstProduct, 10);
			helpers.clickOnElement(WatchImberLocators.firstProduct);
			hooks.test.log(Status.PASS, "Clicked on First Product");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on First Product");
			String screenshotPath = report.captureScreenShot("Not Able to Click on First Product");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on First Product");
		}
	}

	public void clickFindInStore() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 650);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.findInStore, 10);
			helpers.waitForElementToBeClickable(DecorationBirdsLocators.findInStore, 10);
			helpers.clickOnElement(DecorationBirdsLocators.findInStore);
			hooks.test.log(Status.PASS, "Clicked on Find in store");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on Find in store");
			String screenshotPath = report.captureScreenShot("Not Able to Click on Find in store");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on Find in store");
		}
	}

	public void closePopup() {
		try {
			Thread.sleep(2000);
//			helpers.scrollByPixel(0,1000);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.closePopup, 5);
			helpers.waitForElementToBeClickable(DecorationBirdsLocators.closePopup, 5);
			helpers.clickOnElement(DecorationBirdsLocators.closePopup);
			hooks.test.log(Status.PASS, "Popup closed");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to close the Popup");
			String screenshotPath = report.captureScreenShot("Not Able to close the Popup");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to close the Popup");
		}
	}

	public void verifyDeliveryOptionText(String deliveryOption) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(DecorationBirdsLocators.verifyDeliveryOptions, 10);
			String Delivery_option = helpers.getText(DecorationBirdsLocators.verifyDeliveryOptions);
			System.out.println("================================================================");
			System.out.println(Delivery_option);
			System.out.println("================================================================");
			helpers.softAssertContaing(deliveryOption, Delivery_option);
			hooks.test.log(Status.PASS, "verify Delivery option Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Delivery option text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Delivery option text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Delivery option text");
		}
	}

}
