package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.CrystalPendatantsLocators;
import uistore.SunglassesAceteLocators;
import uistore.WatchImberLocators;
import utils.base;
import utils.helper;
import utils.report;

public class SunglassesAcetepage {
	
	WebDriver driver;
	helper helpers;
	
	public SunglassesAcetepage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);
	}
	
	public void hoverOnAccessories() {
		try {
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.Accessories, 10);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.Accessories, 10);
			helpers.hoverOverElement(SunglassesAceteLocators.Accessories);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Hover Successful on Accessories");
		} catch (Exception e) {
			System.out.println("This is catch block error of hoverOnAccessories ");
			hooks.test.log(Status.FAIL, "Hover Failure");
			String screenshotPath = report.captureScreenShot("Hover Failure");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Hover Failure");
		}
	}
	
	public void clickOnSunglasses() {
		try {
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.sunglasses, 10);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.sunglasses, 10);
			helpers.clickOnElement(SunglassesAceteLocators.sunglasses);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Clicked on Sunglasses");
		} catch (Exception e) {
			System.out.println("This is catch block error of hoverOnAccessories ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Sunglasses");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Sunglasses");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Sunglasses");
		}
	}
	
	public void verifyTheUrlForSunglasses(String sunglass) {
		try {
			String Sunglass = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Sunglass: " + Sunglass);
			System.out.println("=====================================================================");
			helpers.softAssertContaing(Sunglass, sunglass);
			hooks.test.log(Status.PASS, "verify Url after Click on Sunglass");
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("This is catch block error of verifyTheUrlForSunglasses ");
			hooks.test.log(Status.FAIL, "Not able to verify Url after Click on Sunglass");
			String screenshotPath = report.captureScreenShot("Not able to verify Url after Click on Sunglass");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to verify Url after Click on Sunglass");
		}
	}
	
	public void clickOnMaterial() {
		try {
			helpers.scrollByPixel(0, 430);
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.material, 10);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.material, 10);
			helpers.clickOnElement(SunglassesAceteLocators.material);
			hooks.test.log(Status.PASS, "click On Material");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnMaterial ");
			hooks.test.log(Status.FAIL, "Not able to click On Material");
			String screenshotPath = report.captureScreenShot("Not able to click On Material");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Material");
		}
	}
	
	public void clickOnAcetate() {
		try {
//			helpers.scrollByPixel(0, 430);
			Thread.sleep(1000);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.acetate, 10);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.acetate, 10);
			helpers.clickOnElement(SunglassesAceteLocators.acetate);
			hooks.test.log(Status.PASS, "click On Acetate");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnAcetate ");
			hooks.test.log(Status.FAIL, "Not able to click On Acetate");
			String screenshotPath = report.captureScreenShot("Not able to click On Acetate");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Acetate");
		}
	}
	
	public void ShowProductsForSunglasses() {
		try {
			helpers.scrollByPixel(0, 430);
			Thread.sleep(2000);
			/*Here calling the showproduct from another testcase as both the Xpaths are same*/
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.showProduct, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.showProduct, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.showProduct);
			hooks.test.log(Status.PASS, "click On Show Products");
		} catch (Exception e) {
			System.out.println("This is catch block error of ShowProductsForSunglasses ");
			hooks.test.log(Status.FAIL, "Not able to click On Show Products");
			String screenshotPath = report.captureScreenShot("Not able to click On Show Products");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Show Products");
		}
	}
	
	public void verifySunglassesText(String glass) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.verifySunglass, 10);
			String Glass = helpers.getText(SunglassesAceteLocators.verifySunglass);
			System.out.println("================================================================");
			System.out.println(Glass);
			System.out.println("================================================================");
			helpers.softAssertContaing(glass, Glass);
			hooks.test.log(Status.PASS, "verify Sunglass Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Sunglass text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Sunglass text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Sunglass text");
		}
	}
	
	public void clickOnFirstProductForSunglass() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 440);
			helpers.waitForElementToBeVisible(WatchImberLocators.firstProduct, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.firstProduct, 10);
			helpers.clickOnElement(WatchImberLocators.firstProduct);
			hooks.test.log(Status.PASS, "Clicked on First Product");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on First Product");
			String screenshotPath = report.captureScreenShot("Not Able to Click on First Product");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on First Product");
		}
	}
	
	public void clickCareMaintenance() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0,1000);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.careMainten, 10);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.careMainten, 10);
			helpers.clickOnElement(SunglassesAceteLocators.careMainten);
			hooks.test.log(Status.PASS, "Clicked on CareMaintenance");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on CareMaintenance");
			String screenshotPath = report.captureScreenShot("Not Able to Click on CareMaintenance");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on CareMaintenance");
		}
	}
	
	public void clickVerifyBookAppointment() {
		try {
			Thread.sleep(2000);
//			helpers.scrollByPixel(0,680);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.bookAppointment, 5);
			helpers.waitForElementToBeClickable(SunglassesAceteLocators.bookAppointment, 5);
			helpers.clickOnElement(SunglassesAceteLocators.bookAppointment);
			hooks.test.log(Status.PASS, "Click Book Appointment");

			
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SunglassesAceteLocators.verifyBookAppointment, 10);
			String appointment = helpers.getText(SunglassesAceteLocators.verifyBookAppointment);
			System.out.println("================================================================");
			System.out.println(appointment);
			System.out.println("================================================================");
			helpers.softAssertContaing("Book an appointment", appointment);
			hooks.test.log(Status.PASS, "verify Book Appointment Text");
			helpers.scrollUpByPixel(0, 1000);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Book Appointment text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Book Appointment text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Book Appointment text");
		}
	}

}
