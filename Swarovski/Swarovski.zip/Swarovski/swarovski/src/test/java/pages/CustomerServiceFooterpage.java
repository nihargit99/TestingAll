package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.CustomerServiceFooterLocators;

import utils.base;
import utils.helper;
import utils.report;

public class CustomerServiceFooterpage {
	
	helper helpers;
	WebDriver driver;
	
	public CustomerServiceFooterpage(WebDriver driver) {
		this.driver=driver;
		helpers= new helper(driver);
	}
	
	public void scrollToFoter() {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.customerService, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.customerService, 10);
			helpers.javascriptScroll(CustomerServiceFooterLocators.customerService);
			hooks.test.log(Status.PASS, "Scrolled to Footer section");
		} catch (Exception e) {
			System.out.println("This is catch block error of scrollToFoter ");
			hooks.test.log(Status.FAIL, "Unable to Scrolled to Footer section");
			String screenshotPath = report.captureScreenShot("Unable to Scrolled to Footer section");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Unable to Scrolled to Footer section");
		}
	}
	
	public void clickCustomerServiceOverview(String CustomerServiceOverview) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.customerServiceOverview, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.customerServiceOverview, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.customerServiceOverview);
			Thread.sleep(2000);
			String customerServiceOverview = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking CustomerServiceOverview: " + customerServiceOverview);
			System.out.println("=====================================================================");
			helpers.softAsserting(customerServiceOverview, CustomerServiceOverview);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on customer Service Overview and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of customerServiceOverview ");
			hooks.test.log(Status.FAIL, "Not able Clicked on customer Service Overview and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on customer Service Overview and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on customer Service Overview and verify URL");
		}
	}
	
	public void clickOrderStatus(String OrderStatus) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.orderstatus, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.orderstatus, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.orderstatus);
			Thread.sleep(2000);
			String orderStatus = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking orderstatus: " + orderStatus);
			System.out.println("=====================================================================");
			helpers.softAsserting(orderStatus, OrderStatus);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on order status and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of OrderStatus ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Order Status and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Order Status and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Order Status and verify URL");
		}
	}
	
	public void clickgiftCardBalance(String giftCardBalance) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.giftCardBalance, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.giftCardBalance, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.giftCardBalance);
			Thread.sleep(2000);
			String GiftCardBalance = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking giftCardBalance: " + GiftCardBalance);
			System.out.println("=====================================================================");
			helpers.softAsserting(GiftCardBalance, giftCardBalance);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on gift Card Balance and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of giftCardBalance ");
			hooks.test.log(Status.FAIL, "Not able Clicked on gift Card Balance and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on gift Card Balance and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on gift Card Balance and verify URL");
		}
	}
	
	public void clickShipping(String Shipping) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.shipping, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.shipping, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.shipping);
			Thread.sleep(2000);
			String shipping = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Shipping: " + shipping);
			System.out.println("=====================================================================");
			helpers.softAsserting(shipping, Shipping);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Shipping and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickShipping ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Shipping and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Shipping and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Shipping and verify URL");
		}
	}
	
	public void clickReturnExchange(String returnExchange) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.returnExchange, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.returnExchange, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.returnExchange);
			Thread.sleep(2000);
			String ReturnExchange = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking ReturnExchange: " + ReturnExchange);
			System.out.println("=====================================================================");
			helpers.softAsserting(ReturnExchange, returnExchange);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on ReturnExchange and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of ReturnExchange ");
			hooks.test.log(Status.FAIL, "Not able Clicked on ReturnExchange and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on ReturnExchange and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on ReturnExchange and verify URL");
		}
	}
	
	public void clickContactUs(String contactUs) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.contactUs, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.contactUs, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.contactUs);
			Thread.sleep(2000);
			String ContactUs = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking ContactUs: " + ContactUs);
			System.out.println("=====================================================================");
			helpers.softAsserting(ContactUs, contactUs);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on ContactUs and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of ContactUs ");
			hooks.test.log(Status.FAIL, "Not able Clicked on ContactUs and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on ContactUs and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on ContactUs and verify URL");
		}
	}
	
	public void clickSizeGuide(String SizeGuide) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.sizeGuide, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.sizeGuide, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.sizeGuide);
			Thread.sleep(2000);
			String sizeGuide = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking SizeGuide: " + sizeGuide);
			System.out.println("=====================================================================");
			helpers.softAsserting(sizeGuide, SizeGuide);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on SizeGuide and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of SizeGuide ");
			hooks.test.log(Status.FAIL, "Not able Clicked on SizeGuide and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on SizeGuide and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on SizeGuide and verify URL");
		}
	}
	
	public void clickStoreFinder(String StoreFinder) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.storeFinder, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.storeFinder, 10);
			helpers.clickOnElement(CustomerServiceFooterLocators.storeFinder);
			Thread.sleep(2000);
			String storeFinder = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking StoreFinder: " + storeFinder);
			System.out.println("=====================================================================");
			helpers.softAsserting(storeFinder, StoreFinder);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Store Finder and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Store Finder ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Store Finder and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Store Finder and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Store Finder and verify URL");
		}
	}
	
	public void verifyMembership(String membership) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CustomerServiceFooterLocators.membership, 10);
			helpers.waitForElementToBeClickable(CustomerServiceFooterLocators.membership, 10);
			String Membership = helpers.getText(CustomerServiceFooterLocators.membership);
			System.out.println("================================================================");
			System.out.println(Membership);
			System.out.println("================================================================");
			helpers.softAsserting(membership, Membership);
			hooks.test.log(Status.PASS, "verify Membership Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Membership text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Membership text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Membership text");
		}
	}

}
