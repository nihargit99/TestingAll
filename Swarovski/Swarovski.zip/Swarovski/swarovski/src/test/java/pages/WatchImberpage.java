package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.WatchImberLocators;
import utils.base;
import utils.helper;
import utils.report;

public class WatchImberpage {

	WebDriver driver;
	helper helpers;

	public WatchImberpage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);

	}

	public void hoverOnWatches() {
		try {
			helpers.waitForElementToBeVisible(WatchImberLocators.watches, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.watches, 10);
			helpers.hoverOverElement(WatchImberLocators.watches);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Hover Successful on Watches");
		} catch (Exception e) {
			System.out.println("This is catch block error of hoverOnWatches ");
			hooks.test.log(Status.FAIL, "Hover Failure");
			String screenshotPath = report.captureScreenShot("Hover Failure");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Hover Failure");
		}
	}

	public void clickOnImber() {
		try {
			helpers.waitForElementToBeClickable(WatchImberLocators.Imber, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.Imber, 10);
			helpers.clickOnElement(WatchImberLocators.Imber);
			hooks.test.log(Status.PASS, "Click on Imber");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnImber ");
			hooks.test.log(Status.FAIL, "Not able to Click on Imber");
			String screenshotPath = report.captureScreenShot("Not able to Click on Imber");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to Click on Imber");
		}
	}

	public void verifyUrlForImber(String string) {
		try {
			String url = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL ater clicking Imber: " + url);
			System.out.println("=====================================================================");
			helpers.softAssertContaing(url, string);
			hooks.test.log(Status.PASS, "verify Url after Click on Imber");
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnImber ");
			hooks.test.log(Status.FAIL, "Not able to verify Url after Click on Imber");
			String screenshotPath = report.captureScreenShot("Not able to verify Url after Click on Imber");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to verify Url after Click on Imber");
		}
	}

	public void clickOnCategories() {
		try {
			helpers.scrollByPixel(0, 430);
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(WatchImberLocators.categories, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.categories, 10);
			helpers.clickOnElement(WatchImberLocators.categories);
			hooks.test.log(Status.PASS, "click On Categories");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnCategories ");
			hooks.test.log(Status.FAIL, "Not able to click On Categories");
			String screenshotPath = report.captureScreenShot("Not able to click On Categories");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Categories");
		}
	}

	public void clickOnClose() {
		try {
			helpers.scrollByPixel(0, 400);
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(WatchImberLocators.closeCategories, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.closeCategories, 10);
			helpers.clickOnElement(WatchImberLocators.closeCategories);
			hooks.test.log(Status.PASS, "click On Close");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnClose");
			hooks.test.log(Status.FAIL, "Not able to click On Close");
			String screenshotPath = report.captureScreenShot("Not able to click On Close");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Close");
		}
	}

	public void clickOnWishlist() {
		try {
			Thread.sleep(2000);
			helpers.scrollUpByPixel(0, 5000);
			helpers.waitForElementToBeVisible(WatchImberLocators.wishlist, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.wishlist, 10);
			helpers.clickOnElement(WatchImberLocators.wishlist);
			hooks.test.log(Status.PASS, "click On wishlist");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnWishlist");
			hooks.test.log(Status.FAIL, "Not able to click On wishlist");
			String screenshotPath = report.captureScreenShot("Not able to click On wishlist");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On wishlist");
		}
	}

	public void verifyText(String text) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(WatchImberLocators.verifyWishlist, 10);
			String webText = helpers.getText(WatchImberLocators.verifyWishlist);
			System.out.println("================================================================");
			System.out.println(webText);
			System.out.println("================================================================");
			helpers.softAsserting(text, webText);
			hooks.test.log(Status.PASS, "verify wishlist Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the wishlist text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the wishlist text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the wishlist text");
		}
	}

	public void goBackToPreviousPage() {
		try {
			Thread.sleep(2000);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Navigated back to the previous page");
		} catch (Exception e) {
			System.out.println("Error while navigating back: " + e.getMessage());
			hooks.test.log(Status.FAIL, "Failed to navigate back to the previous page");
			String screenshotPath = report.captureScreenShot("Failed to navigate back");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Failed to navigate back");
		}
	}

	public void verifyResultsKeywords(String results) {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 430);
			helpers.waitForElementToBeVisible(WatchImberLocators.results, 10);
			String result = helpers.getText(WatchImberLocators.results);
			System.out.println("================================================================");
			System.out.println(result);
			System.out.println("================================================================");
			helpers.softAssertContaing(results, result);
			hooks.test.log(Status.PASS, "verify Results Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the wishlist text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Results text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Results text");
		}
	}

	public void clickOnFirstProductForWatches() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 440);
			helpers.waitForElementToBeVisible(WatchImberLocators.firstProduct, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.firstProduct, 10);
			helpers.clickOnElement(WatchImberLocators.firstProduct);
			hooks.test.log(Status.PASS, "Clicked on First Product");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on First Product");
			String screenshotPath = report.captureScreenShot("Not Able to Click on First Product");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on First Product");
		}
	}

	public void clickOnAddToBag() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 520);
			helpers.waitForElementToBeVisible(WatchImberLocators.addBook, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.addBook, 10);
			helpers.clickOnElement(WatchImberLocators.addBook);
			hooks.test.log(Status.PASS, "Click on Add To Bag");
		} catch (InterruptedException e) {

			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on Add To Bag and Continue");
			String screenshotPath = report.captureScreenShot("Not Able to Click on Add To Bag and Continue");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on Add To Bag and Continue");
		}
	}

	public void clickOnViewShoppingBag() {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(WatchImberLocators.viewShopingBag, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.viewShopingBag, 10);
			helpers.clickOnElement(WatchImberLocators.viewShopingBag);
			hooks.test.log(Status.PASS, "Click on View Shopping Bag");
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on View Shopping Bag");
			String screenshotPath = report.captureScreenShot("Not Able to Click on View Shopping Bag");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on View Shopping Bag");
		}
	}

	public void verifyLogginButton(String login) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(WatchImberLocators.verifyLogin, 10);
			String logins = helpers.getText(WatchImberLocators.verifyLogin);
			System.out.println("================================================================");
			System.out.println(logins);
			System.out.println("================================================================");
			helpers.softAsserting(login, logins);
			hooks.test.log(Status.PASS, "verify Loggin Button");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the verify Loggin Button");
			String screenshotPath = report.captureScreenShot("Not Able to verify the verify Loggin Button");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the verify Loggin Button");
		}
	}

}
