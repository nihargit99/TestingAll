package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.CrystalPendatantsLocators;
import uistore.SilverRingLocators;
import uistore.WatchImberLocators;
import utils.base;
import utils.helper;
import utils.report;

public class silverRingpage {
	WebDriver driver;
	helper helpers;
	
	public silverRingpage(WebDriver driver) {
		this.driver=driver;
		helpers = new helper(driver);	
	}
	
	public void hoverOnSwarovskiDiamonds() {
		try {
			helpers.waitForElementToBeVisible(SilverRingLocators.swarovskiDiamonds, 10);
			helpers.waitForElementToBeClickable(SilverRingLocators.swarovskiDiamonds, 10);
			helpers.hoverOverElement(SilverRingLocators.swarovskiDiamonds);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Hover Successful on swarovski Diamonds");
		} catch (Exception e) {
			System.out.println("This is catch block error of hoverOnSwarovskiDiamonds ");
			hooks.test.log(Status.FAIL, "Hover Failure");
			String screenshotPath = report.captureScreenShot("Hover Failure");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Hover Failure");
		}
	}
	
	public void clickOnEternity() {
		try {
			helpers.scrollByPixel(0, 300);
			helpers.waitForElementToBeVisible(SilverRingLocators.eternity, 10);
			helpers.waitForElementToBeClickable(SilverRingLocators.eternity, 10);
			helpers.clickOnElement(SilverRingLocators.eternity);
			Thread.sleep(2000);
			hooks.test.log(Status.PASS, "Clicked on Eternity");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnEternity ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Eternity");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Eternity");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Eternity");
		}
	}
	
	public void verifyTheUrlForEternity(String Eternity) {
		try {
			Thread.sleep(1000);
			String eternity = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking Sunglass: " + eternity);
			System.out.println("=====================================================================");
			helpers.softAssertContaing(eternity, Eternity);
			hooks.test.log(Status.PASS, "verify Url after Click on Eternity");

		} catch (Exception e) {
			System.out.println("This is catch block error of verifyTheUrlForEternity ");
			hooks.test.log(Status.FAIL, "Not able to verify Url after Click on Eternity");
			String screenshotPath = report.captureScreenShot("Not able to verify Url after Click on Eternity");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to verify Url after Click on Eternity");
		}
	}
	
	public void clickOnRings() {
		try {
//			helpers.scrollByPixel(0, 430);
			Thread.sleep(1000);
			helpers.waitForElementToBeVisible(SilverRingLocators.ring, 10);
			helpers.waitForElementToBeClickable(SilverRingLocators.ring, 10);
			helpers.clickOnElement(SilverRingLocators.ring);
			hooks.test.log(Status.PASS, "click On Rings");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnRings ");
			hooks.test.log(Status.FAIL, "Not able to click On Rings");
			String screenshotPath = report.captureScreenShot("Not able to click On Rings");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Rings");
		}
	}
	
	public void ShowProductsForRings() {
		try {
			helpers.scrollByPixel(0, 420);
			Thread.sleep(2000);

			/*
			 * Here calling the show product from another test case as both the Xpaths are same
			 */
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.showProduct, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.showProduct, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.showProduct);
			hooks.test.log(Status.PASS, "click On Show Products");
		} catch (Exception e) {
			System.out.println("This is catch block error of ShowProductsForSunglasses ");
			hooks.test.log(Status.FAIL, "Not able to click On Show Products");
			String screenshotPath = report.captureScreenShot("Not able to click On Show Products");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Show Products");
		}
	}
	
	public void verifyRingsText(String Rings) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SilverRingLocators.verifyRing, 10);
			String rings = helpers.getText(SilverRingLocators.verifyRing);
			System.out.println("================================================================");
			System.out.println(rings);
			System.out.println("================================================================");
			helpers.softAssertContaing(Rings, rings);
			hooks.test.log(Status.PASS, "verify Rings Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Rings text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Rings text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Rings text");
		}
	}
	
	public void clickOnSterlingSilver() {
		try {
//			helpers.scrollByPixel(0, 430);
			Thread.sleep(1000);
			helpers.waitForElementToBeVisible(SilverRingLocators.sterlingSilver, 10);
			helpers.waitForElementToBeClickable(SilverRingLocators.sterlingSilver, 10);
			helpers.clickOnElement(SilverRingLocators.sterlingSilver);
			hooks.test.log(Status.PASS, "click On sterling silver");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickOnSterlingSilver ");
			hooks.test.log(Status.FAIL, "Not able to click On sterling silver");
			String screenshotPath = report.captureScreenShot("Not able to click On sterling silver");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On sterling silver");
		}
	}
	
	public void ShowProductsForSterlingSilver() {
		try {
			helpers.scrollByPixel(0, 420);
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SilverRingLocators.showProductSterlingSilver, 10);
			helpers.waitForElementToBeClickable(SilverRingLocators.showProductSterlingSilver, 10);
			helpers.clickOnElement(SilverRingLocators.showProductSterlingSilver);
			hooks.test.log(Status.PASS, "click On Show Products for sterling silver");
		} catch (Exception e) {
			System.out.println("This is catch block error of ShowProductsForSterlingSilver ");
			hooks.test.log(Status.FAIL, "Not able to click On Show Products sterling silver");
			String screenshotPath = report.captureScreenShot("Not able to click On Show Products sterling silver");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able to click On Show Products sterling silver");
		}
	}
	
	public void clickOnFirstProductForRings() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 450);
			helpers.waitForElementToBeVisible(WatchImberLocators.firstProduct, 10);
			helpers.waitForElementToBeClickable(WatchImberLocators.firstProduct, 10);
			helpers.clickOnElement(WatchImberLocators.firstProduct);
			hooks.test.log(Status.PASS, "Clicked on First Product");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to Click on First Product");
			String screenshotPath = report.captureScreenShot("Not Able to Click on First Product");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on First Product");
		}
	}
	
	public void verifySelectSizeText(String selectSize) {
		try {
			helpers.scrollByPixel(0,550);
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(SilverRingLocators.selectSize, 10);
			String Select_Size = helpers.getText(SilverRingLocators.selectSize);
			System.out.println("================================================================");
			System.out.println(Select_Size);
			System.out.println("================================================================");
			helpers.softAssertContaing(selectSize, Select_Size);
			hooks.test.log(Status.PASS, "verify Select_Size Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the Select_Size text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the Select_Size text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the Select_Size text");
		}
	}



}
