package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.CrystalPendatantsLocators;
import utils.base;
import utils.helper;
import utils.report;


public class CrystalPendantspage {

	WebDriver driver;
	helper helpers;

	public CrystalPendantspage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);
	}

	public void loginAndVerifyLogo() {
		try {

			/*-----------------------------handling Popups-----------------*/
			WebElement landingPopUp = driver
					.findElement(By.xpath("//h4[text()='Swarovski is available in your country']"));
			if (landingPopUp.isDisplayed())
				helpers.clickOnElement(By.xpath("//button[@class='swa-dialog-close js-close-basestore-popup']"));

//			WebElement membersOnlyPopUp = driver.findElement(By.xpath("//h3[contains(text(),'For Members Only')]"));
//			if (membersOnlyPopUp.isDisplayed())
//				helpers.clickOnElement(By.xpath("//div[@class='js-promotionalPopup-close swa-promo__close-icon']"));

			WebElement logo = base.driver.findElement(CrystalPendatantsLocators.Logo); // Locate the logo WebElement
			if (logo.isDisplayed()) {
				System.out.println("Logo is displayed.");
				hooks.test.log(Status.PASS, "Logo Displayed");
	
			} else {
				System.out.println("Logo is not displayed.");
				hooks.test.log(Status.FAIL, "Logo is not Displayed");
				String screenshotPath = report.captureScreenShot("Logo Displayed");
				hooks.test.addScreenCaptureFromPath(screenshotPath, "Logo Displayed");
				
			}
		} catch (Exception e) {
			System.out.println("Error while verifying logo.");
		}
	}

	public void hoverOnJewlleries() {
		try {
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.jewelry, 10);
			helpers.hoverOverElement(CrystalPendatantsLocators.jewelry);
			hooks.test.log(Status.PASS, "Hover Successfully");
		} catch (Exception e) {
			System.out.println("This is cath block---error");
			hooks.test.log(Status.FAIL, "Hover Failure");
			String screenshotPath = report.captureScreenShot("Hover Failure");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Hover Failure");
 
		}
	}

	public void clickOnPendants() {
		try {
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.pendants, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.pendants);
			hooks.test.log(Status.PASS, "Able to click on pendant");
		} catch (Exception e) {
			System.out.println("This is cath block---error");
			hooks.test.log(Status.FAIL, "Not Able to click on Pendant");
			String screenshotPath = report.captureScreenShot("Able to click on Pendant");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to click on Pendant");
		}
	}

	public void verifyUrl(String Pendants) {
		try {
			String url = base.driver.getCurrentUrl();
			System.out.println("Pendant URL: " + url);
			helpers.softAssertContaing(url, Pendants);
			System.out.println("Assertion Passed");
			hooks.test.log(Status.PASS, "Able to verify Pendant URL");
		}
		catch(Exception e){
			System.out.println("This is catch block error of verifyUrl of Pendant");
			hooks.test.log(Status.FAIL, "Not Able to verify Pendant URL");
			String screenshotPath = report.captureScreenShot("Not Able to verify Pendant URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify Pendant URL");
		}
	}

	public void clickOnMaterial() {
		try {
			helpers.scrollByPixel(0, 400);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.material, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.material);
			hooks.test.log(Status.PASS, "Able to Click on material");
			
		}
		catch (Exception e) {	
			System.out.println("This is catch block error of clickOnMaterial");
			hooks.test.log(Status.FAIL, "Not Able to click on material");
			String screenshotPath = report.captureScreenShot("Not Able to click on material");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to click on material");
		}
	}

	public void clickOnCrystals() {
		try {
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.crystals, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.crystals);
			helpers.scrollByPixel(0, 440);
			Thread.sleep(3000);
			hooks.test.log(Status.PASS, "Able to Click on Crystals");
			
		} 
		catch (Exception e) {
			System.out.println("This is catch block error of clickOnCrystals");
			hooks.test.log(Status.FAIL, "Not Able to click on Crystals");
			String screenshotPath = report.captureScreenShot("Not Able to click on Crystals");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to click on Crystals");
		}
	}

	public void clickOnShowProductForCrystal() {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.showProduct, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.showProduct, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.showProduct);
			System.out.println("Testdemo123");
			hooks.test.log(Status.PASS, "Able to Click on Show Product For Crystal");
		} 
		catch (Exception e) {
			System.out.println("This is catch block error of clickOnShowProduct");
			hooks.test.log(Status.FAIL, "Not Able to Click on Show Product For Crystal");
			String screenshotPath = report.captureScreenShot("Not Able to Click on Show Product For Crystal");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on Show Product For Crystal");
		}
	}

	public void verifyCrystal(String crystals) throws InterruptedException {
		try {
			Thread.sleep(3000);
			String url1 = base.driver.getCurrentUrl();
			System.out.println("Crystal URL: " + url1);
			helpers.softAssertContaing(url1, crystals);
			System.out.println("Assertion Passed");
			hooks.test.log(Status.PASS, "Able to verify crystals URL");
			
		} 
		catch (Exception e) {
			System.out.println("This is catch block error of verifyCrystal");
			hooks.test.log(Status.FAIL, "Not Able to verify crystals URL");
			String screenshotPath = report.captureScreenShot("Not Able to verify crystals URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify crystals URL");
		}
	}

	public void clickOnColorAndSelectWhite() {
		try {
			helpers.scrollByPixel(0, 440);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.color,20);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.color,10);
			helpers.clickOnElement(CrystalPendatantsLocators.color);
			hooks.test.log(Status.PASS, "Able to Click on Color");

			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.white,20);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.white, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.white);
			hooks.test.log(Status.PASS, "Able to select white");
			
		} 
		catch (Exception e) {
			System.out.println("This is catch block error of clickOnColorAndSelectWhite");
			hooks.test.log(Status.FAIL, "Not Able to click color and select white");
			String screenshotPath = report.captureScreenShot("Not Able to click color and select white");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to click color and select white");
		}
	}

	public void clickOnShowProductForColor() {
		try {
			
			Thread.sleep(2000);
			helpers.scrollByPixel(0, 400);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.showColor, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.showColor, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.showColor);
			hooks.test.log(Status.PASS, "Able to Click on Show Product for color");

			String url2 = base.driver.getCurrentUrl();
			System.out.println("Color URL: " + url2);
			helpers.softAssertContaing(url2, "white");
			System.out.println("Assertion Passed");
			hooks.test.log(Status.PASS, "Able to verify color URL");
			
		} 
		catch (Exception e) {
			System.out.println("This is catch block error of clickOnShowProduct");
			hooks.test.log(Status.FAIL, "Not Able to Click on Show Product for color");
			String screenshotPath = report.captureScreenShot("Not Able to Click on Show Product for color");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on Show Product for color");
		}
	}

	public void clickOnFirstProductForJewllery() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0,440);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.firstProd, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.firstProd, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.firstProd);
			hooks.test.log(Status.PASS, "Able to Click on First Product");
			Thread.sleep(2000);

		} 
		catch (Exception e) {
			System.out.println("This is catch block error of clickOnFirstProduct");
			hooks.test.log(Status.FAIL, "Not Able to Click on First Product");
			String screenshotPath = report.captureScreenShot("Not Able to Click on First Product");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on First Product");
		}
	}

	public void clickOnAddToBagAndContinue() {
		try {
			Thread.sleep(2000);
			helpers.scrollByPixel(0,520);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.addToBag, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.addToBag, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.addToBag);
			System.out.println("Able to click on add to bag----method passed");
			hooks.test.log(Status.PASS, "Able to Click on Add To Bag");
			
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.continueShopping, 10);
			helpers.waitForElementToBeClickable(CrystalPendatantsLocators.continueShopping, 10);
			helpers.clickOnElement(CrystalPendatantsLocators.continueShopping);
			hooks.test.log(Status.PASS, "Able to Click on Continue");
			Thread.sleep(2000);
			System.out.println("Able to click on add continue Shopping----method passed");
			
		} 
		catch (InterruptedException e) {
			
			System.out.println("This is catch block error of clickOnAddToBagAndContinue");
			hooks.test.log(Status.FAIL, "Not Able to Click on Add To Bag and Continue");
			String screenshotPath = report.captureScreenShot("Not Able to Click on Add To Bag and Continue");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to Click on Add To Bag and Continue");
		}
	}

	public void verifyTestAndCloseBrowser(String text) {
		try {
			Thread.sleep(2000);
//			helpers.scrollByPixel(0,480);
			helpers.waitForElementToBeVisible(CrystalPendatantsLocators.findInStore,20);
			String webText = helpers.getText(CrystalPendatantsLocators.findInStore);
			System.out.println("================================================================");
			System.out.println(webText);
			System.out.println("================================================================");
			helpers.softAsserting(text, webText);
//			Thread.sleep(2000);
			System.out.println("All the methods are passed hence closing the browsers");
			hooks.test.log(Status.PASS, "Able to verify the given text");

		} 
		catch (Exception e) {
			
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the given text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the given text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the given text");
		}
	}

}
