package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import stepDefinitions.hooks;
import uistore.AboutUsLocators;
import utils.base;
import utils.helper;
import utils.report;

public class AboutUspage {

	helper helpers;
	WebDriver driver;

	public AboutUspage(WebDriver driver) {
		this.driver = driver;
		helpers = new helper(driver);
	}

	public void clickAboutSwarovski(String AboutSwarovski) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.aboutSwarovski, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.aboutSwarovski, 10);
			helpers.clickOnElement(AboutUsLocators.aboutSwarovski);
			Thread.sleep(2000);
			String aboutSwarovski = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking AboutSwarovski: " + aboutSwarovski);
			System.out.println("=====================================================================");
			helpers.softAsserting(aboutSwarovski, AboutSwarovski);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on AboutS warovski and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of clickAboutSwarovski ");
			hooks.test.log(Status.FAIL, "Not able Clicked on AboutS warovski and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on AboutS warovski and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on AboutS warovski and verify URL");
		}
	}

	public void clickJobsCarrier(String JobsCarrier) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.jobsCareer, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.jobsCareer, 10);
			helpers.clickOnElement(AboutUsLocators.jobsCareer);
			Thread.sleep(2000);
			String jobsCarrier = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking jobsCareer: " + jobsCarrier);
			System.out.println("=====================================================================");
			helpers.softAsserting(jobsCarrier, JobsCarrier);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on jobsCarrier and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of jobsCarrier ");
			hooks.test.log(Status.FAIL, "Not able Clicked on jobsCarrier and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on jobsCarrier and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on jobsCarrier and verify URL");
		}
	}

	public void clickAlumniCommunity(String AlumniCommunity) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.alumniCommunity, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.alumniCommunity, 10);
			String parentWindow = driver.getWindowHandle();
			helpers.clickOnElement(AboutUsLocators.alumniCommunity);
			helpers.switchToNewWindow();
			Thread.sleep(2000);
			String alumniCommunity = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking alumniCommunity: " + alumniCommunity);
			System.out.println("=====================================================================");
			helpers.softAsserting(alumniCommunity, AlumniCommunity);
			helpers.closeBrowser();
			helpers.switchToParentWindow(parentWindow);
			hooks.test.log(Status.PASS, "Clicked on AlumniCommunity and verify URL");
		}
		catch (Exception e) {
			System.out.println("This is catch block error of alumniCommunity ");
			hooks.test.log(Status.FAIL, "Not able Clicked on alumniCommunity and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on alumniCommunity and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on alumniCommunity and verify URL");
		}
	}

	public void clickForProfessionals(String ForProfessionals) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.forProfessional, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.forProfessional, 10);
			helpers.clickOnElement(AboutUsLocators.forProfessional);
			Thread.sleep(2000);
			String forProfessionals = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking For Professional: " + forProfessionals);
			System.out.println("=====================================================================");
			helpers.softAsserting(forProfessionals, ForProfessionals);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on For Professionals and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of ForProfessionals ");
			hooks.test.log(Status.FAIL, "Not able Clicked on For Professionals and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on For Professionals and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on For Professionals and verify URL");
		}
	}

	public void clickSitemap(String Sitemap) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.sitemap, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.sitemap, 10);
			helpers.clickOnElement(AboutUsLocators.sitemap);
			Thread.sleep(2000);
			String sitemap = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking For sitemap: " + sitemap);
			System.out.println("=====================================================================");
			helpers.softAsserting(sitemap, Sitemap);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Sitemap and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of Sitemap ");
			hooks.test.log(Status.FAIL, "Not able Clicked on Sitemap and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on Sitemap and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on Sitemap and verify URL");
		}
	}

	public void clickKristallwelten(String Kristallwelten) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.kristallwelten, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.kristallwelten, 10);
			helpers.clickOnElement(AboutUsLocators.kristallwelten);
			Thread.sleep(2000);
			String kristallwelten = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking For kristallwelten: " + kristallwelten);
			System.out.println("=====================================================================");
			helpers.softAsserting(kristallwelten, Kristallwelten);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on Sitemap and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of kristallwelten ");
			hooks.test.log(Status.FAIL, "Not able Clicked on kristallwelten and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on kristallwelten and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on kristallwelten and verify URL");
		}
	}
	
	public void clickSwarovskiCreatedDiamonds(String SwarovskiCreatedDiamonds) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.SwarovskiCreatedDiamonds, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.SwarovskiCreatedDiamonds, 10);
			helpers.clickOnElement(AboutUsLocators.SwarovskiCreatedDiamonds);
			Thread.sleep(2000);
			String swarovskiCreatedDiamonds = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking For SwarovskiCreatedDiamonds: " + swarovskiCreatedDiamonds);
			System.out.println("=====================================================================");
			helpers.softAsserting(swarovskiCreatedDiamonds, SwarovskiCreatedDiamonds);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on SwarovskiCreatedDiamonds and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of SwarovskiCreatedDiamonds ");
			hooks.test.log(Status.FAIL, "Not able Clicked on SwarovskiCreatedDiamonds and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on SwarovskiCreatedDiamonds and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on SwarovskiCreatedDiamonds and verify URL");
		}
	}
	
	public void clickCodeOfConduct(String CodeOfConduct) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.codeOfConduct, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.codeOfConduct, 10);
			helpers.clickOnElement(AboutUsLocators.codeOfConduct);
			Thread.sleep(2000);
			String codeOfConduct = base.driver.getCurrentUrl();
			System.out.println("=====================================================================");
			System.out.println("URL after clicking For codeOfConduct: " + codeOfConduct);
			System.out.println("=====================================================================");
			helpers.softAsserting(codeOfConduct, CodeOfConduct);
			helpers.navigateBack();
			hooks.test.log(Status.PASS, "Clicked on codeOfConduct and verify URL");
		} catch (Exception e) {
			System.out.println("This is catch block error of codeOfConduct ");
			hooks.test.log(Status.FAIL, "Not able Clicked on codeOfConduct and verify URL");
			String screenshotPath = report.captureScreenShot("Not able Clicked on codeOfConduct and verify URL");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not able Clicked on codeOfConduct and verify URL");
		}
	}

	public void verifyAboutUs(String AboutUs) {
		try {
			Thread.sleep(2000);
			helpers.waitForElementToBeVisible(AboutUsLocators.aboutUs, 10);
			helpers.waitForElementToBeClickable(AboutUsLocators.aboutUs, 10);
			String aboutUs = helpers.getText(AboutUsLocators.aboutUs);
			System.out.println("================================================================");
			System.out.println(aboutUs);
			System.out.println("================================================================");
			helpers.softAsserting(AboutUs, aboutUs);
			hooks.test.log(Status.PASS, "verify aboutUs Text");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			hooks.test.log(Status.FAIL, "Not Able to verify the aboutUs text");
			String screenshotPath = report.captureScreenShot("Not Able to verify the aboutUs text");
			hooks.test.addScreenCaptureFromPath(screenshotPath, "Not Able to verify the aboutUs text");
		}
	}
}
