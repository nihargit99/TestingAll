package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.DecorationsBirdspage;
import utils.base;

public class DecorationBirdsSteps extends base{
	DecorationsBirdspage decorationsBirdsPage = new DecorationsBirdspage(driver);
	
	@When("User hover over the Decorations for Birds")
	public void user_hover_over_the_decorations_for_birds() {
		decorationsBirdsPage.hoverOnDecorations();
	    
	}
	@When("User click on Birds")
	public void user_click_on_birds() {
		decorationsBirdsPage.clickOnBirds();
	    
	}
	@Then("User verify the URL {string} for Birds")
	public void user_verify_the_url_for_birds(String string) {
		decorationsBirdsPage.verifyTheUrlForBirds(string);
	}
	@Then("User click on Metal")
	public void user_click_on_metal() {
		decorationsBirdsPage.clickOnMetal();
	    
	}
	@Then("User scroll down and click on Show products for Birds")
	public void user_scroll_down_and_click_on_show_products_for_birds() {
		decorationsBirdsPage.ShowProductsForBirds();
	    
	}
	@Then("User verify {string} text is present for Birds")
	public void user_verify_text_is_present_for_birds(String Birds) {
		decorationsBirdsPage.verifyBirdsText(Birds);
	    
	}
	@Then("User click on first product for Birds")
	public void user_click_on_first_product_for_birds() {
		decorationsBirdsPage.clickOnFirstProductForBirds();
	}
	@Then("User scroll down and click on Find in store")
	public void user_scroll_down_and_click_on_find_in_store() {
		decorationsBirdsPage.clickFindInStore();
	}
	@Then("User click to cose the popup")
	public void user_click_to_cose_the_popup() {
		decorationsBirdsPage.closePopup();
	    
	}
	@Then("User verify {string} text and capture screenshot")
	public void user_verify_text_and_capture_screenshot(String Delivery_option) {
		decorationsBirdsPage.verifyDeliveryOptionText(Delivery_option);
	    
	}

}
