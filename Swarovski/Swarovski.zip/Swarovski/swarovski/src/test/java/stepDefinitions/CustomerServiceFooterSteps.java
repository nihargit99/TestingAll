package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CustomerServiceFooterpage;
import utils.base;

public class CustomerServiceFooterSteps extends base{
	
	CustomerServiceFooterpage customerServiceFooterpage = new CustomerServiceFooterpage(driver);
	
	@When("User Scroll to Footer Section")
	public void user_scroll_to_footer_section() {
		customerServiceFooterpage.scrollToFoter();
	  
	}
	@Then("User click on Customer Service Overview and verity {string} in Customer Service and navigate back")
	public void user_click_on_customer_service_overview_and_verity_in_customer_service_and_navigate_back(String Custoemer_Service) {
		customerServiceFooterpage.clickCustomerServiceOverview(Custoemer_Service);
		
	}
	@Then("User click on Order status and verity {string} in Order status and navigate back")
	public void user_click_on_order_status_and_verity_in_order_status_and_navigate_back(String Order_Status) {
		customerServiceFooterpage.clickOrderStatus(Order_Status);
	    
	}
	@Then("User click on Gift card balance and verity {string} in Gift card and navigate back")
	public void user_click_on_gift_card_balance_and_verity_in_gift_card_and_navigate_back(String GiftCard) {
		customerServiceFooterpage.clickgiftCardBalance(GiftCard);
		
	}
	@Then("User click on Shipping and verity {string} and navigate back")
	public void user_click_on_shipping_and_verity_and_navigate_back(String Shipping) {
		customerServiceFooterpage.clickShipping(Shipping);
	    
	}
	@Then("User click on Return & Exchange and verity {string} in Return & Exchange and navigate back")
	public void user_click_on_return_exchange_and_verity_in_return_exchange_and_navigate_back(String ReturnExchange) {
		customerServiceFooterpage.clickReturnExchange(ReturnExchange);
		
	}
	@Then("User click on Contact Us and verity {string} in Contact Us and navigate back")
	public void user_click_on_contact_us_and_verity_in_contact_us_and_navigate_back(String ContactUs) {
		customerServiceFooterpage.clickContactUs(ContactUs);
		
	}
	@Then("User click on Size Guide and verity {string} in Size Guide and navigate back")
	public void user_click_on_size_guide_and_verity_in_size_guide_and_navigate_back(String sizeGuide) {
		customerServiceFooterpage.clickSizeGuide(sizeGuide);
	    
	}
	@Then("User click on Store Finder and verity {string} in Store Finder and navigate back")
	public void user_click_on_store_finder_and_verity_in_store_finder_and_navigate_back(String storeFinder) {
		customerServiceFooterpage.clickStoreFinder(storeFinder);
	    
	}
	@Then("User verify {string} Membership and capture the screenshot")
	public void user_verify_and_capture_the_screenshot(String Membership) {
		customerServiceFooterpage.verifyMembership(Membership);
		
		
	}

}
