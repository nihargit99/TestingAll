package stepDefinitions;


import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Legalpage;
import utils.base;

public class Legalsteps extends base {
	
	Legalpage legalpage= new Legalpage(driver);
	
	@When("User click on Terms Of Use then verify {string} and navigate back")
	public void user_click_on_terms_of_use_then_verify_and_navigate_back(String TermsOfUse) {
		legalpage.clickTermsOfUse(TermsOfUse);
	}
	@When("User click on Terms & Conditions then verify {string} and navigate back")
	public void user_click_on_terms_conditions_then_verify_and_navigate_back(String TermsAndConditions) {
		legalpage.clickTermsAndConditions(TermsAndConditions);
	}
	@When("User click on Privacy Policy then verify {string} and navigate back")
	public void user_click_on_privacy_policy_then_verify_and_navigate_back(String privacyPolicy) {
		legalpage.clickPrivacyPolicy(privacyPolicy);    
	}
	@When("User click on Imprint then verify {string} and navigate back")
	public void user_click_on_imprint_then_verify_and_navigate_back(String imprint) {
		legalpage.clickImprint(imprint);
	}
	@When("User click on CALIFORNIA PROP65 WARNING then verify {string} and navigate back")
	public void user_click_on_california_prop65_warning_then_verify_and_navigate_back(String CaliforniaProp65) {
		legalpage.clickCaliforniaProp65(CaliforniaProp65);
	}
	@When("User click on Accessibility Statement then verify {string} and navigate back")
	public void user_click_on_accessibility_statement_then_verify_and_navigate_back(String accessibility) {
		legalpage.clickAccessibilityStatement(accessibility);
	}
	@When("User click on California Supply Chain Act then verify {string} and navigate back")
	public void user_click_on_california_supply_chain_act_then_verify_and_navigate_back(String californiaSupply) {
		legalpage.clickCaliforniaSupplyChain(californiaSupply);
	}
	@When("User click on California Privacy Rights then verify {string} and navigate back")
	public void user_click_on_california_privacy_rights_then_verify_and_navigate_back(String californiaPrivacy) {
		legalpage.clickCaliforniaPrivacyRights(californiaPrivacy);
	}
	@Then("User verify {string} and capture the screenshot")
	public void user_verify_and_capture_the_screenshot(String Legal) {
		legalpage.verifyLegal(Legal);
	    
	}
	
}
