package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.silverRingpage;
import utils.base;

public class SilverRingSteps extends base{
	
	silverRingpage silverRingpage = new silverRingpage(driver);
	
	@When("User hover over the Swarovski Created Diamonds for Silver Ring")
	public void user_hover_over_the_swarovski_created_diamonds_for_silver_ring() {
		silverRingpage.hoverOnSwarovskiDiamonds();
	    
	}
	@When("User click on Eternity")
	public void user_click_on_eternity() {
		silverRingpage.clickOnEternity();
	   
	}
	@Then("User verify the URL for {string} for Silver Ring")
	public void user_verify_the_url_for_for_silver_ring(String string) {
		silverRingpage.verifyTheUrlForEternity(string);
	}
	@Then("User click on Rings")
	public void user_click_on_rings() {
		silverRingpage.clickOnRings();
	   
	}
	@Then("User scroll down and click on Show products for Silver Ring")
	public void user_scroll_down_and_click_on_show_products_for_silver_ring() {
		silverRingpage.ShowProductsForRings();
	    
	}
	@Then("User verify {string} text is present for Silver Ring")
	public void user_verify_text_is_present_for_silver_ring(String Rings) {
		silverRingpage.verifyRingsText(Rings);
	}
	@Then("User click on sterling silver")
	public void user_click_on_sterling_silver() {
		silverRingpage.clickOnSterlingSilver();
	    
	}
	@Then("User scroll down and click on Show products for sterling silver")
	public void user_scroll_down_and_click_on_show_products_for_sterling_silver() {
		silverRingpage.ShowProductsForSterlingSilver();
		  
	}
	@Then("User Scroll down and click on first product for sterling Silver Ring")
	public void user_scroll_down_and_click_on_first_product_for_sterling_silver_ring() {
		silverRingpage.clickOnFirstProductForRings();
	}
	@Then("User scroll down and  verity {string} and capture screenshot for Silver Ring")
	public void user_scroll_down_and_verity_and_capture_screenshot_for_silver_ring(String size) {
		silverRingpage.verifySelectSizeText(size);
	   
	}

}
