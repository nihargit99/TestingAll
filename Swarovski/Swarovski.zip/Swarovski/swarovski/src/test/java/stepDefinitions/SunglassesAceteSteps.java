package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SunglassesAcetepage;
import utils.base;

public class SunglassesAceteSteps extends base{
	
	SunglassesAcetepage sunglassesAcetepage= new SunglassesAcetepage(driver);
	
	@When("User hover over the Accessories for Sunglasses")
	public void user_hover_over_the_accessories_for_sunglasses() {
		sunglassesAcetepage.hoverOnAccessories();
	    
	}
	@When("User click on Sunglasses")
	public void user_click_on_sunglasses() {
		sunglassesAcetepage.clickOnSunglasses();
	    
	}
	@Then("User verify the URL {string} for Sunglasses")
	public void user_verify_the_url_for_sunglasses(String string) {
		sunglassesAcetepage.verifyTheUrlForSunglasses(string);
		 
	}
	@Then("User Scroll down and click on Material")
	public void user_scroll_down_and_click_on_material() {
		sunglassesAcetepage.clickOnMaterial();
	   
	}
	@Then("User click on Acetate")
	public void user_click_on_acetate() {
		sunglassesAcetepage.clickOnAcetate();
	    
	}
	@Then("User scroll down and click on Show products for sunglasses")
	public void user_scroll_down_and_click_on_show_products_for_sunglasses() {
		sunglassesAcetepage.ShowProductsForSunglasses();		
	   
	}
	@Then("User verify {string} text is present for sunglasses")
	public void user_verify_text_is_present_for_sunglasses(String string1) {
		sunglassesAcetepage.verifySunglassesText(string1);
	}
	@Then("User click on first product for Sunglasses")
	public void user_click_on_first_product_for_sunglasses() {
		sunglassesAcetepage.clickOnFirstProductForSunglass();
	    
	}
	@Then("User scroll down and click Care & maintenance")
	public void user_scroll_down_and_click_care_maintenance() {
		sunglassesAcetepage.clickCareMaintenance();
	    
	}
	@Then("User click and verify Book an appointment")
	public void user_click_and_verify_book_an_appointment() {
		sunglassesAcetepage.clickVerifyBookAppointment();
	}
	/*The last step of verify login button is running from another test case-"WatchImber" feature file*/
}
