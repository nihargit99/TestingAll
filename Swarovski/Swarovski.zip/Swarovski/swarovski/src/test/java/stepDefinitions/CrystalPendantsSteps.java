package stepDefinitions;


import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CrystalPendantspage;
import utils.base;

public class CrystalPendantsSteps extends base{
	
	
	CrystalPendantspage crystalPendantspage = new CrystalPendantspage(driver);
	
	@When("User login to the swarovski website and verify logo")
	public void user_login_to_the_swarovski_website_and_verify_logo() {
		crystalPendantspage.loginAndVerifyLogo();
	}
	
	@When("User hover over the jwelleries")
	public void user_hover_over_the_jwelleries() {
		crystalPendantspage.hoverOnJewlleries();
	   
	}
	@When("User click on Pendants")
	public void user_click_on_pendants() {
		crystalPendantspage.clickOnPendants();
	    
	}
	@Then("User verify URL for {string} for pendants")
	public void user_verify_url_for_for_pendants(String Pendants) {
		crystalPendantspage.verifyUrl(Pendants);   
	}
	
	@Then("User click on Meterial")
	public void user_click_on_meterial() {
		crystalPendantspage.clickOnMaterial();    
	}
	
	@Then("User click on Crystal")
	public void user_click_on_crystal() {
		crystalPendantspage.clickOnCrystals(); 
	}
	
	@Then("User click on ShowProduct for crystal")
	public void user_click_on_show_productForCystal() throws InterruptedException {
		crystalPendantspage.clickOnShowProductForCrystal();   
	}
	
	@Then("User verify URL for {string} for crystals in ongoing page")
	public void user_verify_url_for_for_crystal(String crystals) throws InterruptedException {
		crystalPendantspage.verifyCrystal(crystals);
	}
	
	@Then("User click on color and select white")
	public void user_click_on_color_and_select_white() {
		crystalPendantspage.clickOnColorAndSelectWhite();
	}
	
	@Then("User click on ShowProduct")
	public void user_click_on_show_product() {
		crystalPendantspage.clickOnShowProductForColor();
	}
	
	@Then("User select the first product for jewllery")
	public void user_select_the_first_product_for_jewllery() {
		crystalPendantspage.clickOnFirstProductForJewllery();
	   
	}
	@Then("click on add to bag and click on contuniue shopping")
	public void click_on_add_to_bag_and_click_on_contuniue_shopping() {
		crystalPendantspage.clickOnAddToBagAndContinue();
	}
	@Then("verify the text {string} and capture scrrenshot")
	public void verify_the_text_and_capture_scrrenshot(String string) {
		crystalPendantspage.verifyTestAndCloseBrowser(string);
	   
	}
}
