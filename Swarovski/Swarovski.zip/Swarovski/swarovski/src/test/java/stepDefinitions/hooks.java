package stepDefinitions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import utils.base;
import utils.report;

public class hooks extends base{
	public static ExtentReports reports;
	public static ExtentTest test;
	private static ExtentSparkReporter spark;
	
	
	
	@Given("User Open the browser")
	public void user_open_the_browser()  {
		
		openBrowser();
		try {
			Thread.sleep(3000);
			test.log(Status.PASS, "login to browser and Navigate to Web Site");
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		} 
	}
	
	@Before
	public void initializeTest(Scenario scenario) {
		if(reports == null) {
			reports = new ExtentReports();
			spark = new ExtentSparkReporter("spark.html");
			reports.attachReporter(spark);
		}
		test = reports.createTest(scenario.getName()).assignAuthor("Nihar").pass("details");
	}
	@BeforeAll
	public static void makeReport() {
		reports = report.generateExtentReport("Swarovski");
	}
	@AfterAll
	public static void flushReport() {
		if(reports != null) {
			reports.flush();
		}
	}
	@After
	public static void closeBrowser(){
	    base.driver.quit();
	}

}
