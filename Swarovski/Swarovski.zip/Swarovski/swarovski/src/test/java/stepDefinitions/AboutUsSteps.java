package stepDefinitions;

import io.cucumber.java.en.Then;
import pages.AboutUspage;
import utils.base;

public class AboutUsSteps extends base {
	
	AboutUspage aboutUspage = new AboutUspage(driver);
	
	@Then("User click on About swarovski and verity {string} in About Swarovski and navigate back")
	public void user_click_on_about_swarovski_and_verity_in_about_swarovski_and_navigate_back(String AboutSwarovski) {
		aboutUspage.clickAboutSwarovski(AboutSwarovski);
	}
	@Then("User click on Jobs & Career and verity {string} in Jobs & Career and navigate back")
	public void user_click_on_jobs_career_and_verity_in_jobs_career_and_navigate_back(String jobsCareer) {
		aboutUspage.clickJobsCarrier(jobsCareer);   
	}
	@Then("User click on Alumni Community and verity {string} in Alumni Community and navigate back")
	public void user_click_on_alumni_community_and_verity_in_alumni_community_and_navigate_back(String alumniCommunity) {
		aboutUspage.clickAlumniCommunity(alumniCommunity);
	}
	@Then("User click on For Professional and verity {string} in For Professional and navigate back")
	public void user_click_on_for_professional_and_verity_in_for_professional_and_navigate_back(String forProfessional) {
		aboutUspage.clickForProfessionals(forProfessional);
	}
	@Then("User click on Sitemap and verity {string} in Sitemap and navigate back")
	public void user_click_on_sitemap_and_verity_in_sitemap_and_navigate_back(String sitemap) {
	   aboutUspage.clickSitemap(sitemap);
	}
	@Then("User click on kristallwelten and verity {string} in kristallwelten and navigate back")
	public void user_click_on_kristallwelten_and_verity_in_kristallwelten_and_navigate_back(String kristallwelten) {
		aboutUspage.clickKristallwelten(kristallwelten);
	}
	@Then("User click on Swarovski Created Diamonds and verity {string} in Swarovski Created Diamonds and navigate back")
	public void user_click_on_Swarovski_Created_Diamonds_and_verity_in_Swarovski_Created_Diamonds_and_navigate_back(String SwarovskiCreatedDiamonds) {
		aboutUspage.clickSwarovskiCreatedDiamonds(SwarovskiCreatedDiamonds);
	    
	}
	@Then("User click on Code of Conduct & Policies and verity {string} in  Code of Conduct and navigate back")
	public void user_click_on_code_of_conduct_and_verity_in_code_of_conduct_and_navigate_back(String codeOfConduct) {
		aboutUspage.clickCodeOfConduct(codeOfConduct);
	    
	}
	@Then("User verify {string} AboutUs and capture the screenshot")
	public void user_verify_about_us_and_capture_the_screenshot(String aboutUs) {
		aboutUspage.verifyAboutUs(aboutUs);
	    
	}


}
