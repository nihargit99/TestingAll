package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.WatchImberpage;
import utils.base;

public class WatchImberSteps extends base{
	
	WatchImberpage watchImberpage = new WatchImberpage(driver);
	
		
	@When("User hover over the Watches")
	public void user_hover_over_the_watches() {
		watchImberpage.hoverOnWatches();
	    
	}
	@When("User click on Imber")
	public void user_click_on_imber() {
		watchImberpage.clickOnImber();
	   
	}
	@When("User verify the URL for {string} for imber")
	public void user_verify_the_url_for_for_imber(String string) {
		watchImberpage.verifyUrlForImber(string);
	    
	}
	@When("User Scroll down and click on Categories")
	public void user_scroll_down_and_click_on_categories() {
		watchImberpage.clickOnCategories();
	    
	}
	@When("User Scroll down and click on Close")
	public void user_scroll_down_and_click_on_close() {
		watchImberpage.clickOnClose();
	   
	}
	@When("User scroll to top and click on Wishlist icon")
	public void user_scroll_to_top_and_click_on_wishlist_icon() {
		watchImberpage.clickOnWishlist();
	   
	}
	@Then("User verify {string} text is present")
	public void user_verify_text_is_present(String string) {
		watchImberpage.verifyText(string);
	}
	@Then("User navigate back to previous page")
	public void user_navigate_back_to_previous_page() {
		watchImberpage.goBackToPreviousPage();
	    
	}
	@Then("User scroll down and verify {string} Keywords")
	public void user_scroll_down_and_verify_keywords(String result) {
		watchImberpage.verifyResultsKeywords(result);
	   
	}
	@Then("User click on first product for watches")
	public void user_click_on_first_product_for_watches() {
		watchImberpage.clickOnFirstProductForWatches();
	   
	}
	@Then("User scroll down and click on add to bag")
	public void user_scroll_down_and_click_on_add_to_bag() {
		watchImberpage.clickOnAddToBag();
	    
	}
	@Then("User click on View Shopping Bag")
	public void user_click_on_view_shopping_bag() {
		watchImberpage.clickOnViewShoppingBag();
	   
	}
	@Then("User verify {string} button and capture screenshot")
	public void user_verfty_button_and_capture_screenshot(String login) {
		watchImberpage.verifyLogginButton(login);
	  
	}



}
