package uistore;

import org.openqa.selenium.By;

public class SunglassesAceteLocators {
	
	public static By Accessories=By.xpath("//a[@id='navAccessoriesLink']");
	public static By sunglasses = By.xpath("//span[normalize-space()='Sunglasses']");
	public static By  material = By.xpath("//span[normalize-space()='Material']");
	public static By acetate = By.xpath("(//span[@class='swa-size-caption'][normalize-space()='Acetate'])[2]");
	public static By verifySunglass = By.xpath("//h1[normalize-space()='Sunglasses with Crystals']");
	public static By careMainten = By.xpath("(//li[@role='presentation'])[9]");
	public static By bookAppointment = By.xpath("(//li[@role='presentation'])[11]");
	public static By verifyBookAppointment = By.xpath("(//span[text()='Book an appointment'])[1]");
//	public static By verifyBookAppointment = By.xpath("(//span[@class='swa-cms-link-component__text swa-label-sans--default swa-cms-link-component__text--size'][normalize-space()='Book an appointment'])[1]");
	
	
	
}
