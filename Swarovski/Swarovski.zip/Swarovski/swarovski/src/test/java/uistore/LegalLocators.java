package uistore;

import org.openqa.selenium.By;

public class LegalLocators {
	public static By termsOfUse = By.xpath("(//span[normalize-space()='Terms Of Use'])[1]");
	public static By termsAndConditions = By.xpath("(//span[normalize-space()='Terms & Conditions'])[1]");
	public static By privacyPolicy = By.xpath("(//span[normalize-space()='Privacy Policy'])[1]");
	public static By CALIFORNIAPROP65 = By.xpath("(//span[normalize-space()='California Prop 65 Warning'])[1]");
	public static By imprint = By.xpath("(//span[normalize-space()='Imprint'])[1]");
	public static By accessibility = By.xpath("(//span[normalize-space()='Accessibility Statement'])[1]");
	public static By californiaSupply = By.xpath("(//span[normalize-space()='California Supply Chain Act'])[1]");
	public static By californiaPrivacy = By.xpath("(//span[normalize-space()='California Privacy Rights'])[1]");
	public static By leaglText=By.xpath("(//span[text()='Legal'])[1]");

}
