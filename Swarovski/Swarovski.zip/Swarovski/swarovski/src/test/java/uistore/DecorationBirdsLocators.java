package uistore;

import org.openqa.selenium.By;

public class DecorationBirdsLocators {
	public static By decorations = By.xpath("//span[normalize-space()='Decorations']");
	public static By birds = By.xpath("//span[normalize-space()='Birds']");
	public static By material = By.xpath("//span[normalize-space()='Material']");
	public static By metal = By.xpath("(//span[@class='swa-size-caption'][normalize-space()='Metal'])[2]");
	public static By verifyBirds = By.xpath("//h1[normalize-space()='Birds']");
	public static By findInStore = By.xpath("//span[normalize-space()='Find in store']");
	public static By closePopup = By.xpath("(//button[@role='button'])[8]");
//	public static By closePopup = By.xpath("(//span[@class='swa-link__icon swa-link__icon--close'])[6]");
	public static By verifyDeliveryOptions = By.xpath("//h6[normalize-space()='Delivery options']");

}
