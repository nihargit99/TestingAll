package uistore;

import org.openqa.selenium.By;

public class CustomerServiceFooterLocators {
	public static By customerService = By.xpath("(//div[@class='swa-footer-nav__header'])[1]");
//	public static By customerServiceOverview = By.xpath("(//a[@id='NavCustomerServiceOverviewLink'])[2]");
	public static By customerServiceOverview = By.xpath("(//span[text()='Customer Service Overview'])[1]");
	public static By orderstatus = By.xpath("(//a[@id='OrderStatusCS_NAV-LINK'])[1]");
	public static By giftCardBalance = By.xpath("(//a[@id='NavCSGiftCardBalanceLink'])[1]");
	public static By shipping = By.xpath("(//a[@id='NavCSshippingLink'])[1]");
	public static By returnExchange = By.xpath("(//a[@id='NavCSReturnsLink'])[1]");
	public static By contactUs = By.xpath("(//a[@id='CONTACT-US_NAV-LINK'])[1]");
	public static By sizeGuide = By.xpath("(//a[@id='COVID-19_NAV-LINK'])[1]");
	public static By storeFinder = By.xpath("(//a[@id='NavStoreFinderLink'])[1]");
	public static By membership = By.xpath("(//div[@class='swa-footer-nav__header'])[2]");

}
