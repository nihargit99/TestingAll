package uistore;

import org.openqa.selenium.By;

public class SilverRingLocators {
	
	public static By swarovskiDiamonds=By.xpath("//a[@id='NEWNavSwarovskiCreatedDiamondsLink']");
	public static By eternity= By.xpath("//a[@id='navSCDEternityCollectionLinkUSCA']");
//	public static By ring= By.xpath("//label[text()='Rings']");
	public static By ring = By.xpath("(//label[@for='filter-category-0106'][normalize-space()='Rings'])[2]");
	public static By verifyRing = By.xpath("//h1[normalize-space()='Jewelry: Earrings, Bracelets, Necklaces, Rings']");
	public static By sterlingSilver = By.xpath("(//span[contains(@class,'swa-size-caption')][normalize-space()='Sterling silver'])[2]");
	public static By showProductSterlingSilver = By.xpath("(//span[@class='swa-button__content'])[14]");
	public static By selectSize = By.xpath("//h6[normalize-space()='Select size']");

}
