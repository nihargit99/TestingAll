package uistore;

import org.openqa.selenium.By;

public class AboutUsLocators {
	
	public static By aboutSwarovski = By.xpath("(//span[normalize-space()='About Swarovski'])[2]");
	public static By jobsCareer = By.xpath("(//span[normalize-space()='Jobs & Career'])[1]");
	public static By alumniCommunity = By.xpath("(//span[normalize-space()='Alumni Community'])[1]");
	public static By forProfessional = By.xpath("(//span[normalize-space()='For Professionals'])[2]");
	public static By sitemap = By.xpath("(//span[normalize-space()='Sitemap'])[1]");
	public static By swarovski = By.xpath("(//span[normalize-space()='Swarovski Created Diamonds'])[3]");
	public static By kristallwelten = By.xpath("(//span[normalize-space()='Kristallwelten'])[1]");
	public static By SwarovskiCreatedDiamonds = By.xpath("(//span[text()='Swarovski Created Diamonds'])[3]");
	public static By codeOfConduct = By.xpath("(//span[normalize-space()='Code of Conduct & Policies'])[1]");
	public static By aboutUs = By.xpath("(//span[text()='About Us'])[1]");
	

}
