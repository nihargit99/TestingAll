package uistore;

import org.openqa.selenium.By;

public class CrystalPendatantsLocators {
	
	public static By Logo = By.xpath("(//img[@alt='Swarovski'])[1]");
	public static By jewelry = By.xpath("//a[@id='NAV-BAR_JEWELRY_LINK']");
	public static By pendants = By.xpath("//span[normalize-space()='Pendants']");
	public static By material = By.xpath("//span[normalize-space()='Material']");
	public static By crystals = By.xpath("//div[@id='dropdown-facet-value-list-product_material']//span[@class='swa-size-caption'][normalize-space()='Crystals']");
//	public static By showProduct = By.xpath("(//div[@id='filter-dropdown-footer-product_material']//button[@id='filterApply']//span[text()])[2]");
	public static By showProduct = By.xpath("(//span[@class='swa-button__content'])[11]");
	public static By color = By.xpath("//div[@data-filter-id='consumer_color']");
	public static By white = By.xpath("//div[@id='filter-dropdown-consumer_color']//li[1]");
//	public static By white = By.xpath("(//span[contains(@class,'swa-items-caption')][normalize-space()='White'])[3]");
//	public static By showColor = By.xpath("(//button[@id='filterApply'])[4]");
	public static By showColor = By.xpath("(//span[@class='swa-button__content'])[14]");
	public static By firstProd = By.xpath("(//div[@class='swa-product-tile-plp-wrapper'])[1]");
//	public static By addToBag = By.xpath("//button[@id='addToCartButton']");
	public static By addToBag = By.xpath("//span[text()='Add to bag']");
	public static By continueShopping = By.xpath("//span[normalize-space()='Continue shopping']");
//	public static By findInStore = By.xpath("//span[normalize-space()='Find in store']");
	public static By findInStore = By.xpath("//span[text()=' Find in store']");

}


