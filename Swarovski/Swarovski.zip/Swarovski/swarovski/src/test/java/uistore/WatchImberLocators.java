package uistore;

import org.openqa.selenium.By;

public class WatchImberLocators {
	
	public static By watches=By.xpath("//a[@id='navWatchesLink']");
	public static By Imber = By.xpath("//span[normalize-space()='Imber']");
	public static By categories = By.xpath("//span[normalize-space()='Categories']");
	public static By closeCategories = By.xpath("(//span[@class='swa-button__text swa-label-sans--medium-strong'][normalize-space()='Close'])[2]");
	public static By wishlist = By.xpath("(//span[@aria-label='left-wishlist image'])[1]");
	public static By verifyWishlist = By.xpath("//h1[@class='swa-headline-serif--big']");
	public static By results = By.xpath("//div[@class='swa-filter-desktop__results-count swa-text-sans--comment']");
	public static By firstProduct = By.xpath("(//div[@class='swa-product-tile-plp-wrapper'])[1]");
	public static By addBook = By.xpath("(//span[@class='swa-button__content'])[4]");
	public static By viewShopingBag = By.xpath("//span[normalize-space()='View Shopping Bag']");
	public static By verifyLogin = By.xpath("(//span[@class='swa-link__item'][normalize-space()='Login'])[1]");
	

}

